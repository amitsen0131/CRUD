import random
from django.utils import timezone
from ..models import Incident

def generate_incident_id():
    # Generate a unique incident ID
    unique_id = f'RMG{random.randint(10000, 99999)}{timezone.now().year}'
    while Incident.objects.filter(incident_id=unique_id).exists():
        unique_id = f'RMG{random.randint(10000, 99999)}{timezone.now().year}'
    return unique_id
