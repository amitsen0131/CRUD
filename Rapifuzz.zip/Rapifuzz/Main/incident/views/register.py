from django.shortcuts import render, redirect
from django.views import View
from ..models import Signup
from django.contrib import messages
from django.contrib.auth.hashers import make_password

class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        # Get form data
        user_type = request.POST.get('user_type')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        pincode = request.POST.get('pincode')
        isd_code = request.POST.get('isd_code')
        mobile_number = request.POST.get('mobile_number')
        fax = request.POST.get('fax')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Basic validation
        if password != confirm_password:
            messages.error(request, 'Passwords do not match!')
            return redirect('register')  # Or render the same page with errors

        # Hash the password before saving
        hashed_password = make_password(password)

        # Save to the database
        signup = Signup(
            user_type=user_type,
            first_name=first_name,
            last_name=last_name,
            email=email,
            address=address,
            country=country,
            state=state,
            city=city,
            pincode=pincode,
            isd_code=isd_code,
            mobile_number=mobile_number,
            fax=fax,
            phone=phone,
            password=hashed_password  # Store hashed password
        )
        signup.save()

        messages.success(request, 'Signup successful!')
        return redirect('login_page')  # Replace with your success page
