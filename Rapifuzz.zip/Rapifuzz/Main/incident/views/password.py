from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from django.contrib.auth.hashers import make_password
from ..models import Signup

class ForgotPasswordView(View):
    def get(self, request):
        return render(request, 'password.html')

    def post(self, request):
        email = request.POST.get('email')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if new_password != confirm_password:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'forgot_password.html', {'error': 'Passwords do not match.'})

        user = Signup.objects.filter(email=email).first()

        if user:
            # Update password
            user.password = make_password(new_password)
            user.save()

            messages.success(request, 'Password reset successful! Please log in with your new password.')
            return redirect('login_page')
        else:
            messages.error(request, 'No account found with that email address.')
            return render(request, 'password.html', {'error': 'No account found with that email address.'})
