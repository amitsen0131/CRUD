from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from django.contrib.auth import authenticate, login
from ..models import Signup


class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        # Get form data
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Authenticate user
        user = Signup.objects.filter(email=email).first()

        if user and user.check_password(password):
            # Log the user in
            login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('create_incident_page')  # Redirect to the dashboard or home page after login
        else:
            messages.error(request, 'Invalid email or password')
            return render(request, 'login.html', {'error': 'Invalid email or password'})
