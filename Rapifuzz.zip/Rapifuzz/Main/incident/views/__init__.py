from .login import LoginView
from .register import RegisterView
from .password import ForgotPasswordView
from .incident import create_incident, view_incidents, edit_incident, delete_incident