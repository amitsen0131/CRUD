from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from ..models import Incident
from datetime import datetime
from .utils import generate_incident_id
from django.utils import timezone
import pytz

@login_required
def create_incident(request):
    if request.method == 'POST':
        incident_type = request.POST.get('incident_type')
        reporter_name = f"{request.user.first_name} {request.user.last_name}"
        incident_details = request.POST.get('incident_details')
        priority = request.POST.get('priority')
        status = request.POST.get('status', 'Open')  # Default status is 'Open'
        reported_date = timezone.now()  # Use timezone-aware now()

        # Generate a unique Incident ID
        incident_id = generate_incident_id()
        while Incident.objects.filter(incident_id=incident_id).exists():
            incident_id = generate_incident_id()

        # Create a new incident record
        incident = Incident(
            user=request.user,
            incident_id=incident_id,
            incident_type=incident_type,
            reporter_name=reporter_name,
            incident_details=incident_details,
            priority=priority,
            status=status,
            reported_date=reported_date  # Save the timezone-aware date
        )
        incident.save()
        messages.success(request, 'Incident created successfully!')
        return redirect('view_incidents_page')

     # Get current time in the specified timezone for display
    current_time_zone = pytz.timezone('Asia/Kolkata')
    current_date = timezone.now().astimezone(current_time_zone).strftime('%Y-%m-%d %H:%M:%S')
    return render(request, 'create_incident.html', {'current_date': current_date})


@login_required
def view_incidents(request):
    # Display only incidents created by the logged-in user
    query = request.GET.get('query')
    incidents = Incident.objects.filter(user=request.user)

    if query:
        # Search by Incident ID if a query is present
        incidents = incidents.filter(incident_id__icontains=query)

    return render(request, 'view_incident.html', {'incidents': incidents})


@login_required
def edit_incident(request, incident_id):
    # Fetch the incident only if it belongs to the logged-in user
    incident = get_object_or_404(Incident, incident_id=incident_id, user=request.user)

    if incident.status == 'Closed':
        messages.error(request, 'Cannot edit a closed incident.')
        return redirect('view_incidents_page')

    if request.method == 'POST':
        incident.incident_type = request.POST.get('incident_type')
        incident.incident_details = request.POST.get('incident_details')
        incident.priority = request.POST.get('priority')
        incident.status = request.POST.get('status')
        incident.save()
        messages.success(request, 'Incident updated successfully!')
        return redirect('view_incidents_page')

    return render(request, 'edit_incident.html', {'incident': incident})


@login_required
def delete_incident(request, incident_id):
    # Ensure the incident belongs to the logged-in user before deletion
    incident = get_object_or_404(Incident, incident_id=incident_id, user=request.user)

    if request.method == 'POST':
        incident.delete()
        messages.success(request, 'Incident deleted successfully!')
        return redirect('view_incidents_page')

    return render(request, 'confirm_delete_incident.html', {'incident': incident})
