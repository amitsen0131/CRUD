from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import random
from django.conf import settings

class Incident(models.Model):
    INCIDENT_TYPES = (
        ('Enterprise', 'Enterprise'),
        ('Government', 'Government'),
    )

    STATUS_CHOICES = (
        ('Open', 'Open'),
        ('In Progress', 'In Progress'),
        ('Closed', 'Closed'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    incident_id = models.CharField(max_length=20, unique=True, blank=True)  # Allow blank for the ID
    incident_type = models.CharField(max_length=50, choices=INCIDENT_TYPES)
    reporter_name = models.CharField(max_length=100)
    incident_details = models.TextField()
    reported_date = models.DateTimeField(auto_now_add=True)  # Save time automatically
    priority = models.CharField(max_length=10, choices=[('High', 'High'), ('Medium', 'Medium'), ('Low', 'Low')])
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)

    def generate_incident_id(self):
        # Generate a unique incident ID
        unique_id = f'RMG{random.randint(10000, 99999)}{timezone.now().year}'
        while Incident.objects.filter(incident_id=unique_id).exists():
            unique_id = f'RMG{random.randint(10000, 99999)}{timezone.now().year}'
        return unique_id

    def save(self, *args, **kwargs):
        if not self.incident_id:
            self.incident_id = self.generate_incident_id()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.incident_id
