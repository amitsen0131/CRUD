from django.urls import path
from .views import *

from django.contrib.auth.decorators import login_required

urlpatterns = [
    path('', LoginView.as_view(), name='login_page'),
    path('forgot-password/', ForgotPasswordView.as_view(), name='forgot_password_page'),
    path('register/', RegisterView.as_view(), name='register_page'),

    path('incident/', login_required(create_incident), name='create_incident_page'),
    path('view-incidents/', login_required(view_incidents), name='view_incidents_page'),
    path('edit-incident/<str:incident_id>/', login_required(edit_incident), name='edit_incident_page'),
    path('delete-incident/<str:incident_id>/', login_required(delete_incident), name='delete_incident'),
]